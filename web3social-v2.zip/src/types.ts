import { z } from "zod";

export const PlatformEnum = z.enum([
  // Original 7
  "farcaster",
  "lens",
  "nostr",
  "mastodon",
  "bluesky",
  "twitter",
  "threads",
  // Additional federated social
  "pixelfed",
  "peertube",
  "lemmy",
  "misskey",
  "friendica",
  "diaspora",
  // Blockchain publishing
  "mirror",
  "steemit",
  // Real-time / messaging
  "matrix",
  "xmpp",
  // Direct channels
  "email",
  "webpush",
  "sms",
  // Storage / distribution
  "ipfs",
]);

export type Platform = z.infer<typeof PlatformEnum>;

export const PostRequestSchema = z.object({
  text: z.string().min(1).max(100000),
  images: z.array(z.string().url()).optional().default([]),
  replyTo: z.string().optional(),
  quote: z.string().optional(),
  channel: z.string().optional(),
  tags: z.array(z.string()).optional().default([]),
});

export type PostRequest = z.infer<typeof PostRequestSchema>;

export const PostResultSchema = z.object({
  platform: PlatformEnum,
  success: z.boolean(),
  id: z.string().optional(),
  url: z.string().url().optional(),
  error: z.string().optional(),
  timestamp: z.string().datetime(),
});

export type PostResult = z.infer<typeof PostResultSchema>;

export const PublishResponseSchema = z.object({
  success: z.boolean(),
  results: z.array(PostResultSchema),
  torrent: z.object({
    infoHash: z.string().optional(),
    magnetUri: z.string().optional(),
  }).optional(),
});

export type PublishResponse = z.infer<typeof PublishResponseSchema>;

export interface Web3SocialConfig {
  platforms: Record<Platform, boolean>;
  torrent: {
    enabled: boolean;
    announceList: string[][];
    seedTimeout: number;
  };
  rss: {
    enabled: boolean;
    outputPath: string;
    title: string;
    description: string;
    link: string;
    language: string;
  };
  server: {
    port: number;
    host: string;
  };
}
