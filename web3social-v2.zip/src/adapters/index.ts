export { PlatformAdapter, truncateToLimit, createResult } from "./base.js";
export { FarcasterAdapter } from "./farcaster.js";
export { LensAdapter } from "./lens.js";
export { NostrAdapter } from "./nostr.js";
export { MastodonAdapter } from "./mastodon.js";
export { BlueskyAdapter } from "./bluesky.js";
export { TwitterAdapter } from "./twitter.js";
export { ThreadsAdapter } from "./threads.js";
// Additional federated social
export { PixelfedAdapter } from "./pixelfed.js";
export { PeerTubeAdapter } from "./peertube.js";
export { LemmyAdapter } from "./lemmy.js";
export { MisskeyAdapter } from "./misskey.js";
export { FriendicaAdapter } from "./friendica.js";
export { DiasporaAdapter } from "./diaspora.js";
// Blockchain publishing
export { MirrorAdapter } from "./mirror.js";
export { SteemitAdapter } from "./steemit.js";
// Real-time / messaging
export { MatrixAdapter } from "./matrix.js";
export { XmppAdapter } from "./xmpp.js";
// Direct channels
export { EmailAdapter } from "./email.js";
export { WebPushAdapter } from "./webpush.js";
export { SmsAdapter } from "./sms.js";
// Storage / distribution
export { IpfsAdapter } from "./ipfs.js";
