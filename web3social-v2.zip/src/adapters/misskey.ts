import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class MisskeyAdapter implements PlatformAdapter {
  platform = "misskey" as const;
  maxChars = 3000;
  supportsImages = true;
  supportsVideo = true;

  private apiToken?: string;
  private baseUrl?: string;

  constructor() {
    this.apiToken = getEnv("MISSKEY_API_TOKEN");
    this.baseUrl = getEnv("MISSKEY_BASE_URL");
  }

  isConfigured(): boolean {
    return envPresent("MISSKEY_API_TOKEN") && envPresent("MISSKEY_BASE_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Misskey not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[Misskey] Posting to ${this.baseUrl}: ${formatted.slice(0, 50)}...`);
      const mockId = Math.random().toString(36).substring(2, 12);
      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.baseUrl}/notes/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
