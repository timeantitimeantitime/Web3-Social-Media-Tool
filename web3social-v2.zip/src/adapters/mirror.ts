import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class MirrorAdapter implements PlatformAdapter {
  platform = "mirror" as const;
  maxChars = 50000;
  supportsImages = true;
  supportsVideo = false;

  private privateKey?: string;

  constructor() {
    this.privateKey = getEnv("MIRROR_PRIVATE_KEY");
  }

  isConfigured(): boolean {
    return envPresent("MIRROR_PRIVATE_KEY");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Mirror not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[Mirror] Publishing essay: ${formatted.slice(0, 50)}...`);
      const mockId = "0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
      return createResult(this.platform, true, {
        id: mockId,
        url: `https://mirror.xyz/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
