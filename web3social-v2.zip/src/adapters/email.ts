import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class EmailAdapter implements PlatformAdapter {
  platform = "email" as const;
  maxChars = 100000;
  supportsImages = true;
  supportsVideo = false;

  private smtpHost?: string;
  private smtpUser?: string;
  private smtpPass?: string;
  private fromAddress?: string;
  private toList?: string;

  constructor() {
    this.smtpHost = getEnv("EMAIL_SMTP_HOST");
    this.smtpUser = getEnv("EMAIL_SMTP_USER");
    this.smtpPass = getEnv("EMAIL_SMTP_PASS");
    this.fromAddress = getEnv("EMAIL_FROM");
    this.toList = getEnv("EMAIL_TO_LIST");
  }

  isConfigured(): boolean {
    return (
      envPresent("EMAIL_SMTP_HOST") &&
      envPresent("EMAIL_SMTP_USER") &&
      envPresent("EMAIL_SMTP_PASS") &&
      envPresent("EMAIL_FROM") &&
      envPresent("EMAIL_TO_LIST")
    );
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Email not configured" });
      }
      const formatted = this.formatText(request.text);
      const recipients = this.toList?.split(",").length || 0;
      console.log(`[Email] Sending to ${recipients} recipients via ${this.smtpHost}: ${formatted.slice(0, 50)}...`);
      const mockId = "email-" + Date.now();
      return createResult(this.platform, true, {
        id: mockId,
        url: `mailto:${this.fromAddress}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
