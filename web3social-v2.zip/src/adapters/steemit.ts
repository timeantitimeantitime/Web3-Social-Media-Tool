import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class SteemitAdapter implements PlatformAdapter {
  platform = "steemit" as const;
  maxChars = 65535;
  supportsImages = true;
  supportsVideo = true;

  private postingKey?: string;
  private username?: string;

  constructor() {
    this.postingKey = getEnv("STEEMIT_POSTING_KEY");
    this.username = getEnv("STEEMIT_USERNAME");
  }

  isConfigured(): boolean {
    return envPresent("STEEMIT_POSTING_KEY") && envPresent("STEEMIT_USERNAME");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Steemit not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[Steemit] Posting as ${this.username}: ${formatted.slice(0, 50)}...`);
      const mockId = "steem-" + Math.random().toString(36).substring(2, 12);
      return createResult(this.platform, true, {
        id: mockId,
        url: `https://steemit.com/@${this.username}/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
