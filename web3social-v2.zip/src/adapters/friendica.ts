import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class FriendicaAdapter implements PlatformAdapter {
  platform = "friendica" as const;
  maxChars = 200000;
  supportsImages = true;
  supportsVideo = true;

  private accessToken?: string;
  private baseUrl?: string;

  constructor() {
    this.accessToken = getEnv("FRIENDICA_ACCESS_TOKEN");
    this.baseUrl = getEnv("FRIENDICA_BASE_URL");
  }

  isConfigured(): boolean {
    return envPresent("FRIENDICA_ACCESS_TOKEN") && envPresent("FRIENDICA_BASE_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Friendica not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[Friendica] Posting to ${this.baseUrl}: ${formatted.slice(0, 50)}...`);
      const mockId = Math.random().toString(36).substring(2, 12);
      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.baseUrl}/display/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
