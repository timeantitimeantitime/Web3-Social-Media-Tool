import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class WebPushAdapter implements PlatformAdapter {
  platform = "webpush" as const;
  maxChars = 120;
  supportsImages = true;
  supportsVideo = false;

  private vapidPublic?: string;
  private vapidPrivate?: string;
  private subscriberCount?: string;

  constructor() {
    this.vapidPublic = getEnv("WEBPUSH_VAPID_PUBLIC");
    this.vapidPrivate = getEnv("WEBPUSH_VAPID_PRIVATE");
    this.subscriberCount = getEnv("WEBPUSH_SUBSCRIBER_COUNT");
  }

  isConfigured(): boolean {
    return envPresent("WEBPUSH_VAPID_PUBLIC") && envPresent("WEBPUSH_VAPID_PRIVATE");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "WebPush not configured" });
      }
      const formatted = this.formatText(request.text);
      const subs = this.subscriberCount || "unknown";
      console.log(`[WebPush] Pushing to ${subs} subscribers: ${formatted.slice(0, 50)}...`);
      const mockId = "push-" + Date.now();
      return createResult(this.platform, true, {
        id: mockId,
        url: "https://developer.mozilla.org/en-US/docs/Web/API/Push_API",
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
