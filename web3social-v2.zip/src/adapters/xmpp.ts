import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class XmppAdapter implements PlatformAdapter {
  platform = "xmpp" as const;
  maxChars = 10000;
  supportsImages = true;
  supportsVideo = false;

  private jid?: string;
  private password?: string;
  private mucRoom?: string;

  constructor() {
    this.jid = getEnv("XMPP_JID");
    this.password = getEnv("XMPP_PASSWORD");
    this.mucRoom = getEnv("XMPP_MUC_ROOM");
  }

  isConfigured(): boolean {
    return envPresent("XMPP_JID") && envPresent("XMPP_PASSWORD");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "XMPP not configured" });
      }
      const formatted = this.formatText(request.text);
      const target = this.mucRoom || this.jid;
      console.log(`[XMPP] Sending to ${target}: ${formatted.slice(0, 50)}...`);
      const mockId = "msg-" + Math.random().toString(36).substring(2, 10);
      return createResult(this.platform, true, {
        id: mockId,
        url: this.mucRoom || `xmpp:${this.jid}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
