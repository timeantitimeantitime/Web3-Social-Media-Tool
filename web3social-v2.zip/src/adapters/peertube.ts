import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class PeerTubeAdapter implements PlatformAdapter {
  platform = "peertube" as const;
  maxChars = 1000;
  supportsImages = true;
  supportsVideo = true;

  private accessToken?: string;
  private baseUrl?: string;

  constructor() {
    this.accessToken = getEnv("PEERTUBE_ACCESS_TOKEN");
    this.baseUrl = getEnv("PEERTUBE_BASE_URL");
  }

  isConfigured(): boolean {
    return envPresent("PEERTUBE_ACCESS_TOKEN") && envPresent("PEERTUBE_BASE_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "PeerTube not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[PeerTube] Uploading to ${this.baseUrl}: ${formatted.slice(0, 50)}...`);
      const mockId = "pt-" + Math.random().toString(36).substring(2, 12);
      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.baseUrl}/w/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
