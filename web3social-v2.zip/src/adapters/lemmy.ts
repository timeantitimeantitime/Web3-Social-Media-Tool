import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class LemmyAdapter implements PlatformAdapter {
  platform = "lemmy" as const;
  maxChars = 20000;
  supportsImages = true;
  supportsVideo = false;

  private username?: string;
  private password?: string;
  private baseUrl?: string;

  constructor() {
    this.username = getEnv("LEMMY_USERNAME");
    this.password = getEnv("LEMMY_PASSWORD");
    this.baseUrl = getEnv("LEMMY_BASE_URL");
  }

  isConfigured(): boolean {
    return envPresent("LEMMY_USERNAME") && envPresent("LEMMY_PASSWORD") && envPresent("LEMMY_BASE_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Lemmy not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[Lemmy] Posting to ${this.baseUrl}: ${formatted.slice(0, 50)}...`);
      const mockId = Math.random().toString(36).substring(2, 10);
      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.baseUrl}/post/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
