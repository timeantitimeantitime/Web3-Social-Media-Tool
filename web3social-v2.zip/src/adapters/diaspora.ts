import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class DiasporaAdapter implements PlatformAdapter {
  platform = "diaspora" as const;
  maxChars = 65535;
  supportsImages = true;
  supportsVideo = true;

  private username?: string;
  private password?: string;
  private baseUrl?: string;

  constructor() {
    this.username = getEnv("DIASPORA_USERNAME");
    this.password = getEnv("DIASPORA_PASSWORD");
    this.baseUrl = getEnv("DIASPORA_BASE_URL");
  }

  isConfigured(): boolean {
    return envPresent("DIASPORA_USERNAME") && envPresent("DIASPORA_PASSWORD") && envPresent("DIASPORA_BASE_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Diaspora not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[Diaspora] Posting to ${this.baseUrl}: ${formatted.slice(0, 50)}...`);
      const mockId = Math.random().toString(36).substring(2, 12);
      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.baseUrl}/posts/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
