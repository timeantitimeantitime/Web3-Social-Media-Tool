import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class MatrixAdapter implements PlatformAdapter {
  platform = "matrix" as const;
  maxChars = 65535;
  supportsImages = true;
  supportsVideo = true;

  private accessToken?: string;
  private homeserver?: string;
  private roomId?: string;

  constructor() {
    this.accessToken = getEnv("MATRIX_ACCESS_TOKEN");
    this.homeserver = getEnv("MATRIX_HOMESERVER");
    this.roomId = getEnv("MATRIX_ROOM_ID");
  }

  isConfigured(): boolean {
    return envPresent("MATRIX_ACCESS_TOKEN") && envPresent("MATRIX_HOMESERVER");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Matrix not configured" });
      }
      const formatted = this.formatText(request.text);
      const target = this.roomId || "public rooms";
      console.log(`[Matrix] Posting to ${target} on ${this.homeserver}: ${formatted.slice(0, 50)}...`);
      const mockId = "$" + Math.random().toString(36).substring(2, 16) + ":" + this.homeserver?.replace("https://", "");
      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.homeserver}/#/room/${this.roomId || "!public"}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
