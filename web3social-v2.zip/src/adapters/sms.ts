import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class SmsAdapter implements PlatformAdapter {
  platform = "sms" as const;
  maxChars = 160;
  supportsImages = false;
  supportsVideo = false;

  private twilioSid?: string;
  private twilioToken?: string;
  private twilioNumber?: string;
  private toNumbers?: string;

  constructor() {
    this.twilioSid = getEnv("TWILIO_SID");
    this.twilioToken = getEnv("TWILIO_TOKEN");
    this.twilioNumber = getEnv("TWILIO_NUMBER");
    this.toNumbers = getEnv("SMS_TO_NUMBERS");
  }

  isConfigured(): boolean {
    return (
      envPresent("TWILIO_SID") &&
      envPresent("TWILIO_TOKEN") &&
      envPresent("TWILIO_NUMBER") &&
      envPresent("SMS_TO_NUMBERS")
    );
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "SMS not configured" });
      }
      const formatted = this.formatText(request.text);
      const recipients = this.toNumbers?.split(",").length || 0;
      console.log(`[SMS] Sending to ${recipients} numbers via Twilio: ${formatted.slice(0, 50)}...`);
      const mockId = "SM" + Date.now();
      return createResult(this.platform, true, {
        id: mockId,
        url: `https://console.twilio.com`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
