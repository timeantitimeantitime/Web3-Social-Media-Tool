import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class PixelfedAdapter implements PlatformAdapter {
  platform = "pixelfed" as const;
  maxChars = 500;
  supportsImages = true;
  supportsVideo = true;

  private accessToken?: string;
  private baseUrl?: string;

  constructor() {
    this.accessToken = getEnv("PIXELFED_ACCESS_TOKEN");
    this.baseUrl = getEnv("PIXELFED_BASE_URL");
  }

  isConfigured(): boolean {
    return envPresent("PIXELFED_ACCESS_TOKEN") && envPresent("PIXELFED_BASE_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "Pixelfed not configured" });
      }
      const formatted = this.formatText(request.text);
      console.log(`[Pixelfed] Posting to ${this.baseUrl}: ${formatted.slice(0, 50)}...`);
      const mockId = "pf-" + Math.random().toString(36).substring(2, 12);
      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.baseUrl}/p/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
