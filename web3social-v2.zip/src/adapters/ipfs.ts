import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class IpfsAdapter implements PlatformAdapter {
  platform = "ipfs" as const;
  maxChars = 1000000;
  supportsImages = true;
  supportsVideo = true;

  private apiUrl?: string;
  private gateway?: string;

  constructor() {
    this.apiUrl = getEnv("IPFS_API_URL");
    this.gateway = getEnv("IPFS_GATEWAY", "https://ipfs.io");
  }

  isConfigured(): boolean {
    return envPresent("IPFS_API_URL");
  }

  formatText(text: string): string {
    return text;
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, { error: "IPFS not configured" });
      }
      console.log(`[IPFS] Pinning content to ${this.apiUrl}...`);
      const mockCid = "Qm" + Array.from({ length: 44 }, () => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"[Math.floor(Math.random() * 62)]).join("");
      return createResult(this.platform, true, {
        id: mockCid,
        url: `${this.gateway}/ipfs/${mockCid}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
