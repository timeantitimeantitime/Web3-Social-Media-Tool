import type { PostRequest, PostResult, Platform, Web3SocialConfig } from "./types.js";
import {
  FarcasterAdapter,
  LensAdapter,
  NostrAdapter,
  MastodonAdapter,
  BlueskyAdapter,
  TwitterAdapter,
  ThreadsAdapter,
  PixelfedAdapter,
  PeerTubeAdapter,
  LemmyAdapter,
  MisskeyAdapter,
  FriendicaAdapter,
  DiasporaAdapter,
  MirrorAdapter,
  SteemitAdapter,
  MatrixAdapter,
  XmppAdapter,
  EmailAdapter,
  WebPushAdapter,
  SmsAdapter,
  IpfsAdapter,
  type PlatformAdapter,
} from "./adapters/index.js";

export class Publisher {
  private adapters: Map<Platform, PlatformAdapter> = new Map();
  private config: Web3SocialConfig;

  constructor(config: Web3SocialConfig) {
    this.config = config;
    this.registerAdapters();
  }

  private registerAdapters(): void {
    const allAdapters: PlatformAdapter[] = [
      // Original 7
      new FarcasterAdapter(),
      new LensAdapter(),
      new NostrAdapter(),
      new MastodonAdapter(),
      new BlueskyAdapter(),
      new TwitterAdapter(),
      new ThreadsAdapter(),
      // Additional federated social
      new PixelfedAdapter(),
      new PeerTubeAdapter(),
      new LemmyAdapter(),
      new MisskeyAdapter(),
      new FriendicaAdapter(),
      new DiasporaAdapter(),
      // Blockchain publishing
      new MirrorAdapter(),
      new SteemitAdapter(),
      // Real-time / messaging
      new MatrixAdapter(),
      new XmppAdapter(),
      // Direct channels
      new EmailAdapter(),
      new WebPushAdapter(),
      new SmsAdapter(),
      // Storage / distribution
      new IpfsAdapter(),
    ];

    for (const adapter of allAdapters) {
      if (adapter.isConfigured() && this.config.platforms[adapter.platform]) {
        this.adapters.set(adapter.platform, adapter);
      }
    }
  }

  getAvailablePlatforms(): Platform[] {
    return Array.from(this.adapters.keys());
  }

  getAllPlatforms(): Array<{ platform: Platform; configured: boolean; enabled: boolean }> {
    const all: Platform[] = [
      // Original 7
      "farcaster", "lens", "nostr", "mastodon", "bluesky", "twitter", "threads",
      // Additional federated social
      "pixelfed", "peertube", "lemmy", "misskey", "friendica", "diaspora",
      // Blockchain publishing
      "mirror", "steemit",
      // Real-time / messaging
      "matrix", "xmpp",
      // Direct channels
      "email", "webpush", "sms",
      // Storage / distribution
      "ipfs",
    ];
    return all.map((p) => ({
      platform: p,
      configured: this.adapters.has(p),
      enabled: this.config.platforms[p] ?? true,
    }));
  }

  async publish(request: PostRequest): Promise<PostResult[]> {
    const results: PostResult[] = [];
    for (const [platform, adapter] of this.adapters) {
      try {
        const result = await adapter.post(request);
        results.push(result);
      } catch (err) {
        results.push({
          platform,
          success: false,
          error: err instanceof Error ? err.message : String(err),
          timestamp: new Date().toISOString(),
        });
      }
    }
    return results;
  }

  async publishToPlatform(platform: Platform, request: PostRequest): Promise<PostResult> {
    const adapter = this.adapters.get(platform);
    if (!adapter) {
      return {
        platform,
        success: false,
        error: `Platform ${platform} is not configured or enabled`,
        timestamp: new Date().toISOString(),
      };
    }
    try {
      return await adapter.post(request);
    } catch (err) {
      return {
        platform,
        success: false,
        error: err instanceof Error ? err.message : String(err),
        timestamp: new Date().toISOString(),
      };
    }
  }
}
