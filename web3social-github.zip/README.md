# Web3Social Stack

Post once, reach everywhere. A TypeScript/Node.js system that publishes a single message across multiple decentralized social platforms simultaneously.

## Platforms

- **Farcaster** — via `@farcaster/hub-nodejs`, NobleEd25519Signer
- **Lens Protocol** — via `@lens-protocol/client`
- **Nostr** — via `nostr-tools`, kind-1 events
- **Mastodon** — via `megalodon`
- **Bluesky** — via `@atproto/api`
- **Twitter/X** — via REST API v2
- **Threads** — via Graph API

## Quick Start

```bash
npm install
cp .env.example .env
# Edit .env with your credentials
npm run build
node dist/cli.js --help
```

## CLI

```bash
# Publish to all platforms
node dist/cli.js post "Hello Web3" --tags web3 social

# List platform status
node dist/cli.js platforms

# Show active torrents
node dist/cli.js seed
```

## REST API

```bash
npm run server
```

- `GET /health` — Service status
- `GET /platforms` — Platform configuration
- `POST /publish` — Publish to all platforms
- `POST /publish/:platform` — Publish to single platform
- `GET /feed.xml` — RSS feed
- `GET /torrents` — Active torrents

## Project Structure

```
web3social/
├── src/
│   ├── cli.ts              # CLI entry point
│   ├── server.ts           # Hono REST API
│   ├── publisher.ts        # Orchestrator
│   ├── rss-generator.ts    # RSS feed writer
│   ├── types.ts            # Zod schemas
│   ├── utils.ts            # Config loader
│   ├── adapters/
│   │   ├── base.ts         # PlatformAdapter interface
│   │   ├── farcaster.ts
│   │   ├── lens.ts
│   │   ├── nostr.ts
│   │   ├── mastodon.ts
│   │   ├── bluesky.ts
│   │   ├── twitter.ts
│   │   └── threads.ts
│   └── torrent/
│       ├── creator.ts      # .torrent creation
│       └── seeder.ts       # WebTorrent seeding
├── package.json
├── tsconfig.json
├── web3social.config.json
└── .env.example
```

## License

MIT
