#!/usr/bin/env node
import "dotenv/config";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { serve } from "@hono/node-server";
import { Publisher } from "./publisher.js";
import { loadConfig } from "./utils.js";
import { PostRequestSchema, PlatformEnum, type Platform } from "./types.js";
import { appendToFeed } from "./rss-generator.js";
import { seedFiles } from "./torrent/seeder.js";
import { createTorrentForFiles } from "./torrent/creator.js";

const config = loadConfig();
const publisher = new Publisher(config);
const app = new Hono();

app.use("*", cors());
app.use("*", logger());

app.get("/health", (c) => {
  return c.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    version: "1.0.0",
    platforms: publisher.getAvailablePlatforms(),
  });
});

app.get("/platforms", (c) => {
  return c.json({
    platforms: publisher.getAllPlatforms(),
  });
});

app.post("/publish", async (c) => {
  try {
    const body = await c.req.json();
    const request = PostRequestSchema.parse(body);

    let torrentInfo: { infoHash?: string; magnetUri?: string } | undefined;

    if (request.images.length > 0 && config.torrent.enabled) {
      try {
        const t = await createTorrentForFiles(
          request.images,
          `web3social-${Date.now()}`,
          config
        );
        torrentInfo = { infoHash: t.infoHash, magnetUri: t.magnetUri };
        await seedFiles(request.images, `web3social-${Date.now()}`, config);
      } catch {
        // Torrent creation is best-effort
      }
    }

    const results = await publisher.publish(request);
    appendToFeed(request, results, config, torrentInfo);

    return c.json({
      success: results.some((r) => r.success),
      results,
      torrent: torrentInfo,
    });
  } catch (err) {
    return c.json(
      {
        success: false,
        error: err instanceof Error ? err.message : String(err),
      },
      400
    );
  }
});

app.post("/publish/:platform", async (c) => {
  try {
    const platform = c.req.param("platform") as Platform;
    PlatformEnum.parse(platform);

    const body = await c.req.json();
    const request = PostRequestSchema.parse(body);

    const result = await publisher.publishToPlatform(platform, request);

    return c.json({
      success: result.success,
      result,
    });
  } catch (err) {
    return c.json(
      {
        success: false,
        error: err instanceof Error ? err.message : String(err),
      },
      400
    );
  }
});

app.get("/feed.xml", async (c) => {
  const { readFileSync } = await import("fs");
  const { resolve } = await import("path");
  try {
    const feed = readFileSync(resolve(process.cwd(), config.rss.outputPath), "utf-8");
    return c.text(feed, 200, { "Content-Type": "application/rss+xml" });
  } catch {
    return c.text('<?xml version="1.0"?><rss version="2.0"><channel><title>Empty</title></channel></rss>', 200, {
      "Content-Type": "application/rss+xml",
    });
  }
});

app.get("/torrents", async (c) => {
  const { getActiveTorrents } = await import("./torrent/seeder.js");
  return c.json({ torrents: getActiveTorrents() });
});

const port = config.server.port;
const host = config.server.host;

console.log(`\n🌐 Web3Social API running at http://${host}:${port}`);
console.log(`   Health:    http://${host}:${port}/health`);
console.log(`   Platforms: http://${host}:${port}/platforms`);
console.log(`   Publish:   POST http://${host}:${port}/publish`);
console.log(`   RSS Feed:  http://${host}:${port}/feed.xml\n`);

serve({
  fetch: app.fetch,
  port,
  hostname: host,
});
