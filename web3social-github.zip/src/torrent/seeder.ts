import WebTorrent from "webtorrent";
import type { Web3SocialConfig } from "../types.js";

let client: InstanceType<typeof WebTorrent> | null = null;
const activeTorrents: Map<string, ReturnType<typeof client["seed"]>> = new Map();

export function getClient(): InstanceType<typeof WebTorrent> {
  if (!client) {
    client = new WebTorrent();
  }
  return client;
}

export async function seedFiles(
  files: string[],
  name: string,
  config: Web3SocialConfig
): Promise<{ infoHash: string; magnetUri: string }> {
  if (!config.torrent.enabled) {
    throw new Error("Torrent seeding is disabled in config");
  }

  const wt = getClient();

  return new Promise((resolve, reject) => {
    const torrent = wt.seed(files, {
      name,
      announceList: config.torrent.announceList,
    });

    const timeout = setTimeout(() => {
      reject(new Error("Torrent seeding timed out"));
    }, config.torrent.seedTimeout);

    torrent.on("error", (err: Error) => {
      clearTimeout(timeout);
      reject(err);
    });

    // WebTorrent seed() doesn't have a "ready" event per se
    // The torrent object is immediately available with metadata
    setTimeout(() => {
      clearTimeout(timeout);
      activeTorrents.set(torrent.infoHash, torrent);
      resolve({
        infoHash: torrent.infoHash,
        magnetUri: torrent.magnetURI,
      });
    }, 1000);
  });
}

export function stopSeeding(infoHash: string): void {
  const torrent = activeTorrents.get(infoHash);
  if (torrent) {
    torrent.destroy();
    activeTorrents.delete(infoHash);
  }
}

export function getActiveTorrents(): Array<{
  infoHash: string;
  magnetUri: string;
  numPeers: number;
  uploadSpeed: number;
  downloadSpeed: number;
}> {
  return Array.from(activeTorrents.entries()).map(([infoHash, torrent]) => ({
    infoHash,
    magnetUri: torrent.magnetURI,
    numPeers: torrent.numPeers,
    uploadSpeed: torrent.uploadSpeed,
    downloadSpeed: torrent.downloadSpeed,
  }));
}

export function destroyClient(): void {
  if (client) {
    client.destroy();
    client = null;
    activeTorrents.clear();
  }
}
