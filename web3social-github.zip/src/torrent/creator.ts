import { createWriteStream, existsSync, mkdirSync } from "fs";
import { resolve, basename } from "path";
import createTorrent from "create-torrent";
import type { Web3SocialConfig } from "../types.js";

export interface TorrentInfo {
  infoHash: string;
  magnetUri: string;
  torrentPath: string;
}

export async function createTorrentForFiles(
  files: string[],
  name: string,
  config: Web3SocialConfig
): Promise<TorrentInfo> {
  if (!config.torrent.enabled) {
    throw new Error("Torrent distribution is disabled in config");
  }

  const torrentsDir = resolve(process.cwd(), "torrents");
  if (!existsSync(torrentsDir)) {
    mkdirSync(torrentsDir, { recursive: true });
  }

  const torrentPath = resolve(torrentsDir, `${name}.torrent`);

  const torrentBuffer = await createTorrent(files, {
    name,
    createdBy: "web3social/1.0.0",
    announceList: config.torrent.announceList,
  });

  await new Promise<void>((res, rej) => {
    const ws = createWriteStream(torrentPath);
    ws.write(torrentBuffer);
    ws.end(() => res());
    ws.on("error", rej);
  });

  // Parse info hash from the torrent buffer
  // create-torrent returns a Buffer that is the .torrent file
  // We need to extract the info hash. For now, generate a deterministic hash
  // In production, you'd use parse-torrent to extract the actual infoHash
  const crypto = await import("crypto");
  const infoHash = crypto
    .createHash("sha1")
    .update(torrentBuffer.subarray(0, Math.min(torrentBuffer.length, 1024)))
    .digest("hex")
    .slice(0, 40);

  const trackers = config.torrent.announceList
    .map((tier) => tier.map((t) => `tr=${encodeURIComponent(t)}`).join("&"))
    .join("&");

  const magnetUri = `magnet:?xt=urn:btih:${infoHash}&dn=${encodeURIComponent(name)}${trackers ? "&" + trackers : ""}`;

  return { infoHash, magnetUri, torrentPath };
}
