declare module "create-torrent" {
  import { Readable } from "stream";
  function createTorrent(
    input: string | string[] | Buffer | Readable,
    opts?: {
      name?: string;
      comment?: string;
      createdBy?: string;
      creationDate?: number;
      private?: boolean;
      pieceLength?: number;
      announceList?: string[][];
      urlList?: string[];
      info?: Record<string, unknown>;
    }
  ): Promise<Buffer>;
  export = createTorrent;
}

declare module "webtorrent" {
  import { EventEmitter } from "events";
  import { Readable } from "stream";

  interface TorrentFile {
    name: string;
    path: string;
    length: number;
    offset: number;
    createReadStream(opts?: { start?: number; end?: number }): Readable;
  }

  interface Torrent {
    infoHash: string;
    magnetURI: string;
    files: TorrentFile[];
    timeRemaining: number;
    received: number;
    downloaded: number;
    uploaded: number;
    downloadSpeed: number;
    uploadSpeed: number;
    progress: number;
    ratio: number;
    numPeers: number;
    path: string;
    destroy(opts?: { destroyStore?: boolean }, cb?: () => void): void;
    on(event: "done", listener: () => void): this;
    on(event: "error", listener: (err: Error) => void): this;
    on(event: "download", listener: (bytes: number) => void): this;
    on(event: "upload", listener: (bytes: number) => void): this;
    on(event: "wire", listener: (wire: unknown, addr: string) => void): this;
  }

  interface WebTorrentInstance extends EventEmitter {
    add(
      torrentId: string | Buffer | Readable,
      opts?: {
        path?: string;
        announce?: string[];
        store?: unknown;
        destroyStoreOnDestroy?: boolean;
      },
      ontorrent?: (torrent: Torrent) => void
    ): Torrent;
    seed(
      input: string | string[] | Buffer | Readable,
      opts?: {
        name?: string;
        comment?: string;
        createdBy?: string;
        announceList?: string[][];
        private?: boolean;
      },
      onseed?: (torrent: Torrent) => void
    ): Torrent;
    destroy(cb?: () => void): void;
  }

  class WebTorrent extends EventEmitter implements WebTorrentInstance {
    constructor(opts?: { tracker?: boolean | { rtc?: boolean } });
    add(
      torrentId: string | Buffer | Readable,
      opts?: Record<string, unknown>,
      ontorrent?: (torrent: Torrent) => void
    ): Torrent;
    seed(
      input: string | string[] | Buffer | Readable,
      opts?: Record<string, unknown>,
      onseed?: (torrent: Torrent) => void
    ): Torrent;
    destroy(cb?: () => void): void;
  }

  export = WebTorrent;
}
