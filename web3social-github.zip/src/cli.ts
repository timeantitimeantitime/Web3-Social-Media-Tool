#!/usr/bin/env node
import "dotenv/config";
import { Command } from "commander";
import { Publisher } from "./publisher.js";
import { loadConfig } from "./utils.js";
import { PostRequestSchema } from "./types.js";
import { appendToFeed } from "./rss-generator.js";
import { seedFiles } from "./torrent/seeder.js";
import { createTorrentForFiles } from "./torrent/creator.js";

const program = new Command();

program
  .name("web3social")
  .description("Post once, reach everywhere - Web3 Social Media Stack")
  .version("1.0.0");

program
  .command("post <text>")
  .description("Publish a message to all configured platforms")
  .option("-i, --images <urls...>", "Image URLs to attach")
  .option("-r, --reply-to <id>", "Reply to a post ID")
  .option("-q, --quote <id>", "Quote a post ID")
  .option("-c, --channel <channel>", "Channel or community")
  .option("-t, --tags <tags...>", "Tags for the post")
  .option("--no-torrent", "Skip torrent creation for images")
  .action(async (text: string, options) => {
    try {
      const config = loadConfig();
      const publisher = new Publisher(config);

      const request = PostRequestSchema.parse({
        text,
        images: options.images || [],
        replyTo: options.replyTo,
        quote: options.quote,
        channel: options.channel,
        tags: options.tags || [],
      });

      console.log("\n🚀 Publishing to platforms...\n");

      let torrentInfo: { infoHash?: string; magnetUri?: string } | undefined;

      if (request.images.length > 0 && config.torrent.enabled && options.torrent !== false) {
        try {
          console.log("📦 Creating torrent for images...");
          const t = await createTorrentForFiles(
            request.images,
            `web3social-${Date.now()}`,
            config
          );
          torrentInfo = { infoHash: t.infoHash, magnetUri: t.magnetUri };
          console.log(`   Magnet: ${t.magnetUri.slice(0, 80)}...`);
          await seedFiles(request.images, `web3social-${Date.now()}`, config);
          console.log("   Seeding started\n");
        } catch (err) {
          console.warn("   Torrent creation failed:", err instanceof Error ? err.message : String(err));
        }
      }

      const results = await publisher.publish(request);
      appendToFeed(request, results, config, torrentInfo);

      console.log("\n📊 Results:");
      console.log("─".repeat(60));
      for (const result of results) {
        const icon = result.success ? "✅" : "❌";
        const status = result.success ? "SUCCESS" : "FAILED";
        console.log(`${icon} ${result.platform.padEnd(12)} ${status.padEnd(8)} ${result.id || result.error || ""}`);
        if (result.url) {
          console.log(`   ${result.url}`);
        }
      }
      console.log("─".repeat(60));

      const successCount = results.filter((r) => r.success).length;
      console.log(`\n✨ Published to ${successCount}/${results.length} platforms\n`);

      process.exit(successCount > 0 ? 0 : 1);
    } catch (err) {
      console.error("\n❌ Error:", err instanceof Error ? err.message : String(err));
      process.exit(1);
    }
  });

program
  .command("platforms")
  .description("List all platforms and their configuration status")
  .action(() => {
    const config = loadConfig();
    const publisher = new Publisher(config);
    const platforms = publisher.getAllPlatforms();

    console.log("\n📱 Platform Status:");
    console.log("─".repeat(50));
    console.log("Platform      Configured  Enabled");
    console.log("─".repeat(50));
    for (const p of platforms) {
      const cfg = p.configured ? "✅ Yes" : "❌ No";
      const enb = p.enabled ? "✅ Yes" : "❌ No";
      console.log(`${p.platform.padEnd(14)} ${cfg.padEnd(12)} ${enb}`);
    }
    console.log("─".repeat(50));
    console.log();
  });

program
  .command("seed")
  .description("Show active torrent seeding status")
  .action(async () => {
    const { getActiveTorrents } = await import("./torrent/seeder.js");
    const torrents = getActiveTorrents();

    console.log("\n🌱 Active Torrents:");
    if (torrents.length === 0) {
      console.log("   No active torrents\n");
      return;
    }

    for (const t of torrents) {
      console.log(`   InfoHash: ${t.infoHash}`);
      console.log(`   Peers: ${t.numPeers} | Up: ${(t.uploadSpeed / 1024).toFixed(1)} KB/s`);
      console.log(`   Magnet: ${t.magnetUri.slice(0, 80)}...\n`);
    }
  });

program.parse();
