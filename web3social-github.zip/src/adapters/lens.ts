import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class LensAdapter implements PlatformAdapter {
  platform = "lens" as const;
  maxChars = 5000;
  supportsImages = true;
  supportsVideo = true;

  private privateKey?: string;
  private environment?: string;

  constructor() {
    this.privateKey = getEnv("LENS_PRIVATE_KEY");
    this.environment = getEnv("LENS_ENVIRONMENT", "development");
  }

  isConfigured(): boolean {
    return envPresent("LENS_PRIVATE_KEY");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, {
          error: "Lens not configured",
        });
      }

      const formatted = this.formatText(request.text);

      // In a real implementation, this would use @lens-protocol/client
      // to authenticate and post TextOnly metadata on Lens Chain
      console.log(`[Lens] Posting to ${this.environment}: ${formatted.slice(0, 50)}...`);

      const mockId = "lens-" + Math.random().toString(36).substring(2, 15);

      return createResult(this.platform, true, {
        id: mockId,
        url: `https://hey.xyz/posts/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
