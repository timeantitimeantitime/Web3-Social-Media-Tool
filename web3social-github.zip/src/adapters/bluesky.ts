import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class BlueskyAdapter implements PlatformAdapter {
  platform = "bluesky" as const;
  maxChars = 300;
  supportsImages = true;
  supportsVideo = false;

  private identifier?: string;
  private password?: string;

  constructor() {
    this.identifier = getEnv("BLUESKY_IDENTIFIER");
    this.password = getEnv("BLUESKY_PASSWORD");
  }

  isConfigured(): boolean {
    return envPresent("BLUESKY_IDENTIFIER") && envPresent("BLUESKY_PASSWORD");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, {
          error: "Bluesky not configured",
        });
      }

      const formatted = this.formatText(request.text);

      // In a real implementation, this would use @atproto/api
      // to create records with link facets and image blobs
      console.log(`[Bluesky] Posting as ${this.identifier}: ${formatted.slice(0, 50)}...`);

      const mockUri = `at://${this.identifier}/app.bsky.feed.post/${Date.now()}`;

      return createResult(this.platform, true, {
        id: mockUri,
        url: `https://bsky.app/profile/${this.identifier}/post/${Date.now()}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
