import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class NostrAdapter implements PlatformAdapter {
  platform = "nostr" as const;
  maxChars = 64000;
  supportsImages = true;
  supportsVideo = true;

  private privateKey?: string;
  private relays: string[] = [];

  constructor() {
    this.privateKey = getEnv("NOSTR_PRIVATE_KEY");
    const relayString = getEnv("NOSTR_RELAYS", "");
    this.relays = relayString.split(",").filter(Boolean);
  }

  isConfigured(): boolean {
    return envPresent("NOSTR_PRIVATE_KEY") && this.relays.length > 0;
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, {
          error: "Nostr not configured",
        });
      }

      const formatted = this.formatText(request.text);

      // In a real implementation, this would use nostr-tools
      // to sign a kind-1 event and publish to multiple WebSocket relays
      console.log(`[Nostr] Publishing to ${this.relays.length} relays: ${formatted.slice(0, 50)}...`);

      // Generate a mock event ID (32-byte hex)
      const mockId = Array.from({ length: 64 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join("");

      return createResult(this.platform, true, {
        id: mockId,
        url: `https://snort.social/e/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
