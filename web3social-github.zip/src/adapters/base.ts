import type { PostRequest, PostResult, Platform } from "../types.js";

export interface PlatformAdapter {
  platform: Platform;
  maxChars: number;
  supportsImages: boolean;
  supportsVideo: boolean;
  isConfigured(): boolean;
  post(request: PostRequest): Promise<PostResult>;
  formatText(text: string): string;
}

export function truncateToLimit(text: string, limit: number): string {
  if (text.length <= limit) return text;
  return text.slice(0, limit - 3) + "...";
}

export function createResult(
  platform: Platform,
  success: boolean,
  overrides?: Partial<PostResult>
): PostResult {
  return {
    platform,
    success,
    timestamp: new Date().toISOString(),
    ...overrides,
  };
}
