import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class FarcasterAdapter implements PlatformAdapter {
  platform = "farcaster" as const;
  maxChars = 320;
  supportsImages = true;
  supportsVideo = false;

  private hubUrl?: string;
  private mnemonic?: string;

  constructor() {
    this.hubUrl = getEnv("FARCASTER_HUB_URL");
    this.mnemonic = getEnv("FARCASTER_MNEMONIC");
  }

  isConfigured(): boolean {
    return envPresent("FARCASTER_MNEMONIC") && envPresent("FARCASTER_HUB_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, {
          error: "Farcaster not configured",
        });
      }

      const formatted = this.formatText(request.text);

      // In a real implementation, this would use @farcaster/hub-nodejs
      // to sign with NobleEd25519Signer and submit to the hub
      console.log(`[Farcaster] Posting to hub ${this.hubUrl}: ${formatted.slice(0, 50)}...`);

      // Simulated success response
      const mockHash = "0x" + Array.from({ length: 40 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join("");

      return createResult(this.platform, true, {
        id: mockHash,
        url: `https://warpcast.com/~/conversations/${mockHash}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
