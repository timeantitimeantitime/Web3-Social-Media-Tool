import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class ThreadsAdapter implements PlatformAdapter {
  platform = "threads" as const;
  maxChars = 500;
  supportsImages = true;
  supportsVideo = true;

  private accessToken?: string;
  private userId?: string;

  constructor() {
    this.accessToken = getEnv("THREADS_ACCESS_TOKEN");
    this.userId = getEnv("THREADS_USER_ID");
  }

  isConfigured(): boolean {
    return envPresent("THREADS_ACCESS_TOKEN") && envPresent("THREADS_USER_ID");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, {
          error: "Threads not configured",
        });
      }

      const formatted = this.formatText(request.text);

      // In a real implementation, this would use the Threads Graph API
      // to create and publish containers
      console.log(`[Threads] Publishing for user ${this.userId}: ${formatted.slice(0, 50)}...`);

      const mockId = Math.random().toString(36).substring(2, 15);

      return createResult(this.platform, true, {
        id: mockId,
        url: `https://www.threads.net/@user/post/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
