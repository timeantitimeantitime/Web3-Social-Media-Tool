import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class TwitterAdapter implements PlatformAdapter {
  platform = "twitter" as const;
  maxChars = 280;
  supportsImages = true;
  supportsVideo = true;

  private apiKey?: string;
  private apiSecret?: string;
  private accessToken?: string;
  private accessSecret?: string;

  constructor() {
    this.apiKey = getEnv("TWITTER_API_KEY");
    this.apiSecret = getEnv("TWITTER_API_SECRET");
    this.accessToken = getEnv("TWITTER_ACCESS_TOKEN");
    this.accessSecret = getEnv("TWITTER_ACCESS_SECRET");
  }

  isConfigured(): boolean {
    return (
      envPresent("TWITTER_API_KEY") &&
      envPresent("TWITTER_API_SECRET") &&
      envPresent("TWITTER_ACCESS_TOKEN") &&
      envPresent("TWITTER_ACCESS_SECRET")
    );
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, {
          error: "Twitter not configured",
        });
      }

      const formatted = this.formatText(request.text);

      // In a real implementation, this would use the Twitter API v2
      // to post tweets with media upload
      console.log(`[Twitter] Posting tweet: ${formatted.slice(0, 50)}...`);

      const mockId = Math.random().toString(36).substring(2, 15);

      return createResult(this.platform, true, {
        id: mockId,
        url: `https://twitter.com/i/web/status/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
