import { getEnv, envPresent } from "../utils.js";
import type { PostRequest, PostResult } from "../types.js";
import { PlatformAdapter, truncateToLimit, createResult } from "./base.js";

export class MastodonAdapter implements PlatformAdapter {
  platform = "mastodon" as const;
  maxChars = 500;
  supportsImages = true;
  supportsVideo = true;

  private accessToken?: string;
  private baseUrl?: string;

  constructor() {
    this.accessToken = getEnv("MASTODON_ACCESS_TOKEN");
    this.baseUrl = getEnv("MASTODON_BASE_URL");
  }

  isConfigured(): boolean {
    return envPresent("MASTODON_ACCESS_TOKEN") && envPresent("MASTODON_BASE_URL");
  }

  formatText(text: string): string {
    return truncateToLimit(text, this.maxChars);
  }

  async post(request: PostRequest): Promise<PostResult> {
    try {
      if (!this.isConfigured()) {
        return createResult(this.platform, false, {
          error: "Mastodon not configured",
        });
      }

      const formatted = this.formatText(request.text);

      // In a real implementation, this would use megalodon
      // to post statuses with media support
      console.log(`[Mastodon] Posting to ${this.baseUrl}: ${formatted.slice(0, 50)}...`);

      const mockId = Math.random().toString(36).substring(2, 15);

      return createResult(this.platform, true, {
        id: mockId,
        url: `${this.baseUrl}/@${mockId}/${mockId}`,
      });
    } catch (err) {
      return createResult(this.platform, false, {
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }
}
