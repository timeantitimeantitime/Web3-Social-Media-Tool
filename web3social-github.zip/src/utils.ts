import { readFileSync, existsSync } from "fs";
import { resolve } from "path";
import { fileURLToPath } from "url";
import type { Web3SocialConfig } from "./types.js";

const __dirname = fileURLToPath(new URL(".", import.meta.url));

export function loadConfig(): Web3SocialConfig {
  const configPath = resolve(process.cwd(), "web3social.config.json");
  if (!existsSync(configPath)) {
    throw new Error(`Config file not found: ${configPath}`);
  }
  return JSON.parse(readFileSync(configPath, "utf-8")) as Web3SocialConfig;
}

export function getEnv(key: string, fallback?: string): string | undefined {
  return process.env[key] ?? fallback;
}

export function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

export function envPresent(key: string): boolean {
  const value = process.env[key];
  return value !== undefined && value.length > 0 && !value.startsWith("demo");
}
