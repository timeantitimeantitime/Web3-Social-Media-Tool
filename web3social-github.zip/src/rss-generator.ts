import { writeFileSync, existsSync, readFileSync } from "fs";
import { resolve } from "path";
import RSS from "rss";
import type { PostResult, PostRequest, Web3SocialConfig } from "./types.js";

let feed: RSS | null = null;

export function getFeed(config: Web3SocialConfig): RSS {
  if (!feed) {
    feed = new RSS({
      title: config.rss.title,
      description: config.rss.description,
      feed_url: `${config.rss.link}/feeds/feed.xml`,
      site_url: config.rss.link,
      language: config.rss.language,
      pubDate: new Date().toISOString(),
    });
  }
  return feed;
}

export function appendToFeed(
  request: PostRequest,
  results: PostResult[],
  config: Web3SocialConfig,
  torrentInfo?: { magnetUri?: string }
): void {
  if (!config.rss.enabled) return;

  const rssFeed = getFeed(config);

  const platformLinks = results
    .filter((r) => r.success && r.url)
    .map((r) => `<a href="${r.url}">${r.platform}</a>`)
    .join(" | ");

  let description = request.text.replace(/
/g, "<br>");
  if (platformLinks) {
    description += `<br><br>Posted to: ${platformLinks}`;
  }
  if (torrentInfo?.magnetUri) {
    description += `<br><br><a href="${torrentInfo.magnetUri}">Magnet Link</a>`;
  }

  rssFeed.item({
    title: request.text.slice(0, 100) + (request.text.length > 100 ? "..." : ""),
    description,
    url: results.find((r) => r.success)?.url || config.rss.link,
    guid: `web3social-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    date: new Date().toISOString(),
    categories: request.tags,
  });

  const outputPath = resolve(process.cwd(), config.rss.outputPath);
  writeFileSync(outputPath, rssFeed.xml({ indent: true }));
}

export function loadExistingFeed(config: Web3SocialConfig): void {
  const outputPath = resolve(process.cwd(), config.rss.outputPath);
  if (existsSync(outputPath)) {
    try {
      const existing = readFileSync(outputPath, "utf-8");
      // RSS library doesn't support parsing existing feeds, so we just keep appending
      // In production, you'd parse and reconstruct
    } catch {
      // Ignore parse errors
    }
  }
}
